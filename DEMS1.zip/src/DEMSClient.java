			import java.io.*;
import java.rmi.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Scanner;

public class DEMSClient {

	String userID, city;
	int RMIPort;
	int portNum;
	DEMSInterface callingObj;
	Scanner sc;
	PrintWriter writer;

	public static void main(String args[]) throws IOException {
		DEMSClient obj = new DEMSClient();
		obj.getID();
		obj.init();
	}
	
	private void getID() throws IOException {
		InputStreamReader is = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(is);
		System.out.println("\nLOGIN***");
		System.out.print("Enter your ID:");
		this.userID = br.readLine();
		if (this.userID.contains("MTL")) {
			this.RMIPort = 1000;
			city = "Montreal";
		} else if (this.userID.contains("OTW")) {
			this.RMIPort = 2000;
			city = "Ottawa";
		} else if (this.userID.contains("TOR")) {
			this.RMIPort = 1099;
			city = "Toronto";
		} else {
			System.out.println("Invalid ID");
		}
		System.out.println("port:"+RMIPort);
	}

	private void init() {
		try {
			this.sc= new Scanner(System.in);
			String hostName = "localhost";
			portNum = RMIPort;
			String registryURL = "rmi://" + hostName + ":" + portNum + "/toronto";
			this.callingObj = (DEMSInterface) Naming.lookup(registryURL);

			if (this.userID.charAt(3) == 'M') {
				boolean res = false;
				res=callingObj.authenticate(userID);
				if(!res) {
					System.out.println("\nAccess Denied!");
					getID();
					init();
					return;
				}
				System.out.print("\nYou are logged in Manager:" + city);
				manager();
			} else if (this.userID.charAt(3) == 'C'){
				System.out.print("\nYou are logged in as client:" + city);
				client();
			}
			else {
				System.out.println("Invalid ID");
				getID();
				init();
			}

		} catch (Exception e) {
			System.out.println("Exception in DEMSClient: " + e);
		}
	}

	private void client() {
		boolean menu = true;
		while (menu) {
			System.out.print(
					"\n\n1.Book Event \n2.Get Booking Schedule \n3.Cancel Event \n4.Log out \nEnter Choice:");
			int ch;
			try {
				ch = Integer.parseInt(sc.nextLine());
			} catch (NumberFormatException e1) {
				e1.printStackTrace();
				break;
			}
			switch (ch) {
				case 1:
					bookEvent();
					break;
				case 2:
					getBookingSchedule();
					break;
				case 3:
					cancelEvent();
					break;
				
				case 4:
					menu = false;
					break;
				default:
					System.out.println("Invalid choice!");
			}
		}
		try {
			getID();
			init();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void bookEvent() {
		String eventID,eventType;
		boolean res = true;
		System.out.println("\nEnter event details:");
		System.out.print("Event ID:");
		eventID= sc.nextLine();
		System.out.print("Event Type:");
		eventType= sc.nextLine();
		try {
			res = this.callingObj.bookEvent(this.userID, eventID, eventType);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		logOperation("bookEvent", eventID, eventType, this.userID, res);
		if(res)
			System.out.println("Event Successfully booked!");
		else 
			System.out.println("Event Not booked!");		
	}

	private void cancelEvent() {
		String eventID;
		boolean res = false;
		System.out.println("\nEnter event details:");
		System.out.print("Event ID:");
		eventID= sc.nextLine();
		try {
			res = this.callingObj.cancelEvent(this.userID, eventID);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		logOperation("cancelEvent", eventID, "NA", this.userID, res);
		if(res)
			System.out.println("Event Successfully cancelled!");
		else 
			System.out.println("Event Not cancelled!");		
	}

	private void getBookingSchedule() {
		try {
			this.callingObj.getBookingSchedule(this.userID);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		logOperation("getBookingSchedule", "NA", "NA", this.userID, true);
		System.out.println("Shown in the "+city+" server console!");
	}

	private void manager() {
		boolean menu = true;
		while (menu) {
			System.out.print(
					"\n\n1.Add Event \n2.Remove Event \n3.Get Event Availablity \n4.Book Event \n5.Get Booking Schedule \n6.Cancel Event \n7.Log out \nEnter Choice:");
			int ch;
			try {
				ch = Integer.parseInt(sc.nextLine());
			} catch (NumberFormatException e1) {
				e1.printStackTrace();
				break;
			}
			switch (ch) {
				case 1:
					addEvent();
					break;
				case 2:
					removeEvent();
					break;
				case 3:
					listEventAvailability();
					break;
				case 4:
					bookEvent();
					break;
				case 5:
					getBookingSchedule();
					break;
				case 6:
					cancelEvent();
					break;
				case 7:
					menu = false;
					break;
				default:
					System.out.println("Invalid choice!");
			}
		}
		try {
			getID();
			init();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void listEventAvailability() {
		String eventType;
		System.out.print("\nEvent Type:");
		eventType= sc.nextLine();
		try {
			this.callingObj.listEventAvailability(eventType);
			logOperation("listEventAvailability", "NA", eventType, this.userID, true);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}
	
	
	public void removeEvent() {
		String eventID,eventType;
		boolean res = false;
		System.out.print("\nEvent ID to remove:");
		eventID= sc.nextLine();
		System.out.print("Event Type:");
		eventType= sc.nextLine();
		try {
			res = this.callingObj.removeEvent(eventID, eventType);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		logOperation("removeEvent", eventID, eventType, this.userID, res);
		if(res)
			System.out.println("Event Successfully removed!");
		else 
			System.out.println("Event Not removed!");		
	}
	
	public void addEvent() {
		String eventID,eventType;
		int bookingCapacity;
		boolean res = false;
		System.out.println("\nEnter event details:");
		System.out.print("Event ID:");
		eventID= sc.nextLine();
		System.out.print("Event Type:");
		eventType= sc.nextLine();
		System.out.print("Booking Capacity:");
		bookingCapacity= Integer.parseInt(sc.nextLine());
		try {
			res = this.callingObj.addEvent(eventID, eventType, bookingCapacity);
			
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		logOperation("addEvent", eventID, eventType, this.userID, res);
		if(res)
			System.out.println("Event Successfully added!");
		else 
			System.out.println("Event Not added!");		
	}
	
	public void logOperation(String name, String eventID, String eventType, String customerID, boolean status) {
		
		try {
			FileWriter fw = new FileWriter("ClientLogs.txt", true);
			BufferedWriter bw = new BufferedWriter(fw);
			writer = new PrintWriter(bw);
		} catch (IOException e) {
			e.printStackTrace();
		}String timeStamp = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
		String log = "\n"+name + "Performed.\nTime: " + timeStamp 
				+ "\nCustomerID: " + customerID+ "\nEventID: " 
				+ eventID +  "\nEventType: " + eventType
				+"\nStatus: "+status ;
		writer.println(log);
		writer.close();
	}

}