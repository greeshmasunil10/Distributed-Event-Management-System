import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.HashMap;

public class DEMSInterfaceImpl extends UnicastRemoteObject implements DEMSInterface {

	protected DEMSInterfaceImpl() throws RemoteException {
		super();
	}

	@Override
	public boolean addEvent(String eventID, String eventType, int bookingCapacity) throws RemoteException {
		boolean res = false;
		if (isValid(eventID, eventType, bookingCapacity)) {
			if (eventID.contains("TOR")) {
				res = DEMSTorontoServer.addEvent(eventID, eventType, bookingCapacity);
				DEMSTorontoServer.logOperation("addEvent", eventID, eventType,"NA","NA", res);
			} else if (eventID.contains("MTL")) {
				res = DEMSMontrealServer.addEvent(eventID, eventType, bookingCapacity);
				DEMSMontrealServer.logOperation("addEvent", eventID, eventType, "NA","NA",res);
			} else if (eventID.contains("OTW")) {
//				res = DEMSOttawaServer.addEvent(eventID, eventType, bookingCapacity);
				DEMSOttawaServer.logOperation("addEvent", eventID, eventType,"NA","NA", res);
			}
		}
		return res;
	}

	@Override
	public boolean removeEvent(String eventID, String eventType) throws RemoteException {
		boolean res = false;
		if(isValid(eventID, eventType)) {
			if (eventID.contains("TOR")) {
				res = DEMSTorontoServer.removeEvent(eventID, eventType);
				DEMSTorontoServer.logOperation("removeEvent", eventID, eventType,"NA","NA", res);
			} else if (eventID.contains("MTL")) {
				res = DEMSMontrealServer.removeEvent(eventID, eventType);
				DEMSMontrealServer.logOperation("removeEvent", eventID, eventType,"NA","NA", res);
			} else if (eventID.contains("OTW")) {
//				res = DEMSOttawaServer.removeEvent(eventID, eventType);
				DEMSOttawaServer.logOperation("removeEvent", eventID, eventType,"NA","NA", res);
			}
		}
		return res;
	}

	@Override
	public void listEventAvailability(String eventType) throws RemoteException {
			DEMSTorontoServer.dispEventAvailability(eventType);
			DEMSTorontoServer.logOperation("bookEvent", "NA", eventType,"NA","NA", true);
	}

	@Override
	public boolean bookEvent(String customerID, String eventID, String eventType) throws RemoteException {
		boolean res =  false;
		if(isValid(eventID, eventType)) {
			if(customerID.contains("TOR")) {
				res = DEMSTorontoServer.bookEvent(customerID, eventID, eventType);
				DEMSTorontoServer.logOperation("bookEvent", eventID, eventType,"NA","NA", res);
			}
			else if(customerID.contains("OTW")) {
				res = DEMSOttawaServer.bookEvent(customerID, eventID, eventType);
				DEMSOttawaServer.logOperation("bookEvent", eventID, eventType,"NA","NA", res);
			}
			else if(customerID.contains("MTL")) {
				res = DEMSMontrealServer.bookEvent(customerID, eventID, eventType);
				DEMSMontrealServer.logOperation("bookEvent", eventID, eventType,"NA","NA", res);
			}
		}
		return res;
	}

	@Override
	public void getBookingSchedule(String customerID) throws RemoteException {
		// TODO Auto-generated method stub
		if(customerID.contains("TOR")) {
			DEMSTorontoServer.getBookingSchedule(customerID);
//			DEMSTorontoServer.logOperation("getBookingSchedule", customerID, true);
		}
		else if(customerID.contains("OTW")) {
			DEMSOttawaServer.getBookingSchedule(customerID);
			DEMSOttawaServer.logOperation("getBookingSchedule", "NA", "NA",customerID,"NA", true);
		}
//		MTL
		else{
			DEMSMontrealServer.getBookingSchedule(customerID);
//			DEMSMontrealServer.logOperation("getBookingSchedule", customerID, true);
			
		}
	}

	@Override
	public boolean cancelEvent(String customerID, String eventID) throws RemoteException {
		boolean res = false;
		if(customerID.contains("TOR")) {
			res = DEMSTorontoServer.cancelEvent(customerID, eventID);
			DEMSTorontoServer.logOperation("cancelEvent", eventID, "NA",customerID,"NA", res);
		}
		else if(customerID.contains("OTW")) {
			res = DEMSOttawaServer.cancelEvent(customerID, eventID);
			DEMSOttawaServer.logOperation("cancelEvent",eventID, "NA",customerID,"NA", res);
		}
//		MTL
		else if(customerID.contains("MTL")){
			res = DEMSMontrealServer.cancelEvent(customerID, eventID);
			DEMSMontrealServer.logOperation("cancelEvent", eventID, "NA",customerID,"NA", res);
		}
		return res;
	}
	
	@Override
	public boolean authenticate(String id) throws RemoteException {
		boolean res = false;
		if(id.contains("TOR")) {
			res = DEMSTorontoServer.authenticate(id);
		} else if(id.contains("MTL")) {
			res = DEMSMontrealServer.authenticate(id);
		} else if(id.contains("OTW")) {
			res = DEMSOttawaServer.authenticate(id);
		} 		
		return res;
	}
	
	
	
//	ignoring validation for the date in the acronyms
	private boolean isValid(String eventID, String eventType, int bookingCapacity) {
		return (eventType.equalsIgnoreCase("Conferences") || eventType.equalsIgnoreCase("Seminars")
				|| eventType.equalsIgnoreCase("Trade Shows")) 
				&& (eventID.length() == 10 && (eventID.substring(0, 3).equals("TOR") || eventID.substring(0, 3).equals("MTL")
						|| eventID.substring(0, 3).equals("OTW")) && (eventID.charAt(3) == 'M' || eventID.charAt(3) == 'A' || eventID.charAt(3) == 'E')) 
				&& (bookingCapacity > 0);
	}

	private boolean isValid( String eventID, String eventType) {
		return (eventType.equalsIgnoreCase("Conferences") || eventType.equalsIgnoreCase("Seminars")
				|| eventType.equalsIgnoreCase("Trade Shows")) 
				&& (eventID.length() == 10 && (eventID.substring(0, 3).equals("TOR") || eventID.substring(0, 3).equals("MTL")
						|| eventID.substring(0, 3).equals("OTW")) && (eventID.charAt(3) == 'M' || eventID.charAt(3) == 'A' || eventID.charAt(3) == 'E'));
	}
	
}
