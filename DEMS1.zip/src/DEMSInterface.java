import java.rmi.*;
import java.util.HashMap;

public interface DEMSInterface extends Remote {
	public boolean addEvent(String eventID, String eventType, int bookingCapacity) throws java.rmi.RemoteException;

	public boolean removeEvent(String eventID, String eventType) throws java.rmi.RemoteException;

	public void listEventAvailability(String eventType) throws java.rmi.RemoteException;

	public boolean bookEvent(String customerID, String eventID, String eventType) throws java.rmi.RemoteException;

	public void getBookingSchedule(String customerID) throws java.rmi.RemoteException;

	public boolean cancelEvent(String customerID, String eventID) throws java.rmi.RemoteException;

	boolean authenticate(String id) throws RemoteException;

} // end interface
